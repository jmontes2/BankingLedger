﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankingLedger
{
    public class Account
    {
        // Class to define account

        public static int lastAcctNumUsed = -1;

        private int acctNumber;
        private string lastName;
        private string firstName;
        private decimal balance;
        private string loginId;
        private string password;

        // Constructor
        public Account(string lastName, string firstName, string loginId, string password)
        {
            // Generate account number
            AccountNumber = ++lastAcctNumUsed;

            // Finish creating account
            Lastname = lastName;
            FirstName = firstName;
            LoginId = loginId;
            Password = password;
        }

        // Properties
        public int AccountNumber
        {
            get
            {
                return acctNumber;
            }
            set
            {
                acctNumber = value;
            }
        }
        public string Lastname
        {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
            }
        }
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                firstName = value;
            }
        }
        public string LoginId
        {
            get
            {
                return loginId;
            }
            set
            {
                loginId = value;
            }
        }
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }
        public decimal Balance
        {
            get
            {
                return balance;
            }
            set
            {
                balance = value;
            }
        }
    }
}
