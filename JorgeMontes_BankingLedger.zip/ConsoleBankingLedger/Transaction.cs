﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankingLedger
{
    public enum TransactionType { Deposit, Withdrawal }
    public class Transaction
    {
        // Class defines transactions, and uses Enum above for transaction type.

        private static int lastTransactionId = 0;

        private int transactionId;              // Transaction ID
        private int accountNumber;              // Account number
        private TransactionType transType;      // Type of transaction
        private DateTime transactionDate;       // Date of transaction
        private decimal transactionAmount;      // The amount (always > 0)

        // Constructor
        public Transaction (int accountNumber, DateTime transactionDate, TransactionType transType, decimal transactionAmount)
        {
            // Generate transaction id
            TransactionId = nextId();

            // Finish creating transaction
            AccountNumber = accountNumber;
            TransType = transType;
            TransactionDate = transactionDate;
            TransactionAmount = transactionAmount;
        }

        // Properties
        public int TransactionId
        {
            get
            {
                return transactionId;
            }
            set
            {
                transactionId = value;
            }
        }
        public int AccountNumber
        {
            get
            {
                return accountNumber;
            }
            set
            {
                accountNumber = value;
            }
        }
        public TransactionType TransType
        {
            get
            {
                return transType;
            }
            set
            {
                transType = value;
            }
        }
        public DateTime TransactionDate
        {
            get
            {
                return transactionDate;
            }
            set
            {
                transactionDate = value;
            }
        }
        public decimal TransactionAmount
        {
            get
            {
                return transactionAmount;
            }
            set
            {
                transactionAmount = value;
            }
        }

        // Methods
        private int nextId()
        {
            // Assign transaction id
            return ++lastTransactionId;
        }
    }
}
