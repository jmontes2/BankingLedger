﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankingLedger
{
    public class AccountList : List<Account>
    {
        // Class to hold collection of accounts.  Uses default constructor, and inherits from List interface.

    }
}
