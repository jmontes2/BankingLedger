﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankingLedger
{
    public class TransactionList : List<Transaction>
    {
        // Class to hold collection of transactions.  Uses default constructor, and inherits from List interface.

        // Methods
        public void AddTransaction(int accountNumber, DateTime transactionDate, TransactionType transType, decimal transactionAmount)
        {
            Transaction myTransaction = new Transaction(accountNumber, transactionDate, transType, transactionAmount);
            Add(myTransaction);
        }
    }

}
