﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankingLedger
{
    class Program
    {
        // Class contains Main method. Displays menu and uses classes for processing.

        static void Main(string[] args)
        {
            // Var initializations and create objects
            string menuSelection;
            int acctLoggedInto = -1;    // -1 means no account
            Account objAccount = new Account("dummy", "dummy", "dummy", "dummy");   // Unused object for reference only
            AccountList accountList = new AccountList();                            // List of accounts
            TransactionList transactionList = new TransactionList();                // Transaction History

            do
            {
                // Present menu and wait for selection
                Console.Clear();
                Console.WriteLine("1 - Create an account");
                Console.WriteLine("2 - Login to your account");
                Console.WriteLine("3 - Deposit");
                Console.WriteLine("4 - Withdrawal");
                Console.WriteLine("5 - Check Balance");
                Console.WriteLine("6 - See Transaction History");
                Console.WriteLine("7 - Logout");
                Console.WriteLine("8 - Exit");
                Console.WriteLine("\n");
                Console.Write("Please select: ");

                menuSelection = Console.ReadLine();

                // Process selection
                switch (menuSelection.ToUpper())
                {
                    case "1":       // Create an account
                        // Ensure user is logged out
                        if (acctLoggedInto != -1)
                        {
                            Console.WriteLine("\nYou are being logged out of the current account.");
                            Console.Write("\nPress <Enter> to continue...");
                            Console.ReadLine();
                            acctLoggedInto = -1;
                        }

                        // Request user info
                        Console.WriteLine("\n--CREATE ACCOUNT--");
                        Console.Write("Please enter your Last Name: ");
                        string lastName = Console.ReadLine();

                        Console.Write("Please enter your First Name: ");
                        string firstName = Console.ReadLine();

                        Console.Write("Please enter a Login ID: ");
                        string loginId = Console.ReadLine();

                        Console.Write("Please enter a Password: ");
                        string password = Console.ReadLine();

                        // Create account and add it to the AccountList
                        objAccount = new Account(lastName, firstName, loginId, password);
                        acctLoggedInto = objAccount.AccountNumber;
                        accountList.Add(objAccount);
                        Console.WriteLine("\nAccount created. Your account number is: " + objAccount.AccountNumber);

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                    case "2":       // Login to your account
                        // Ensure user is logged out
                        if (acctLoggedInto != -1)
                        {
                            Console.WriteLine("\nYou are being logged out of the current account.");
                            Console.Write("\nPress <Enter> to continue...");
                            Console.ReadLine();
                            acctLoggedInto = -1;
                        }

                        Console.WriteLine("\n--LOGIN--");
                        Console.Write("Please enter your Login Id: ");
                        string myLogin = Console.ReadLine();
                        Console.Write("Please enter your Password: ");
                        string myPassword = Console.ReadLine();

                        // Search for account with same credentials
                        foreach (Account acct in accountList)
                        {
                            if (acct.LoginId == myLogin && acct.Password == myPassword)
                            {
                                acctLoggedInto = acct.AccountNumber;
                                Console.WriteLine("Welcome {0}! You are logged in.", acct.FirstName);
                                break;
                            }
                        }

                        // Ensure user is logged in
                        if (acctLoggedInto == -1)
                        {
                            Console.WriteLine("\nCan not find an account that matches your information. Please try again.");
                            Console.Write("\nPress <Enter> to continue...");
                            Console.ReadLine();
                            break;
                        }

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                    case "3":       // Deposit
                        // Ensure user is logged in
                        if (acctLoggedInto == -1)
                        {
                            Console.WriteLine("\nYou must first login to an account.");
                            Console.Write("\nPress <Enter> to continue...");
                            Console.ReadLine();
                            break;
                        }

                        // Request deposit amount
                        Console.WriteLine("\n--DEPOSIT--");
                        Console.Write("Please enter amount: ");
                        decimal depositAmount = decimal.Parse(Console.ReadLine());

                        // Make deposit, and add it to TransactionList collection
                        transactionList.AddTransaction(objAccount.AccountNumber, DateTime.Now, TransactionType.Deposit, depositAmount);
                        objAccount.Balance += depositAmount;
                        Console.WriteLine("Amount deposit complete.");

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                    case "4":       // Withdrawal
                        // Ensure user is logged in
                        if (acctLoggedInto == -1)
                        {
                            Console.WriteLine("\nYou must first login to an account.");
                            Console.Write("\nPress <Enter> to continue...");
                            Console.ReadLine();
                            break;
                        }

                        // Request withdrawal amount
                        Console.WriteLine("\n--WITHDRAWAL--");
                        Console.Write("Please enter amount: ");
                        decimal withdrawalAmount = decimal.Parse(Console.ReadLine());

                        // Make withdrawal, and add it to TransactionList collection
                        transactionList.AddTransaction(objAccount.AccountNumber, DateTime.Now, TransactionType.Withdrawal, withdrawalAmount);
                        objAccount.Balance -= withdrawalAmount;
                        Console.WriteLine("Amount withdrawal complete.");

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                    case "5":       // Check Balance
                        // Ensure user is logged in
                        if (acctLoggedInto == -1)
                        {
                            Console.WriteLine("\nYou must first login to an account.");
                            Console.Write("\nPress <Enter> to continue...");
                            Console.ReadLine();
                            break;
                        }

                        // Reference the Balance property
                        Console.WriteLine("\n--CHECK BALANCE--");
                        Console.WriteLine("\nBalance: {0:C}", objAccount.Balance);

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                    case "6":       // See Transaction History
                        // Ensure user is logged in
                        if (acctLoggedInto == -1)
                        {
                            Console.WriteLine("\nYou must first login to an account.");
                            Console.Write("\nPress <Enter> to continue...");
                            Console.ReadLine();
                            break;
                        }

                        Console.WriteLine("\n--TRANSACTION SUMMARY--\n");
                        Console.WriteLine("Date     Acct Type     Amount");
                        Console.WriteLine("-----------------------------");
                        // Iterate through TransactionList collection
                        foreach (Transaction t in transactionList)
                        {
                            if (t.AccountNumber == acctLoggedInto)
                            {
                                Console.WriteLine(t.TransactionDate.ToShortDateString() + "  " + t.AccountNumber.ToString() + "  " +
                                    t.TransType.ToString() + "  " + t.TransactionAmount.ToString());
                            }
                        }
                        Console.WriteLine("\nAcct Balance: {0:C}", objAccount.Balance);

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                    case "7":       // Logout
                        Console.WriteLine("\n--LOGOUT--");
                        // Set to -1
                        acctLoggedInto = -1;
                        Console.WriteLine("You successfully logged out.");

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                    case "8":       // Exit
                        Console.WriteLine("\n--EXIT--");
                        break;
                    default:
                        Console.WriteLine("\n*** Please select 1-8.");

                        Console.Write("\nPress <Enter> to continue...");
                        Console.ReadLine();
                        break;
                }

            } while (menuSelection != "8");
        }
    }
}
