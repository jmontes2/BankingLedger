﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConsoleBankingLedger;

namespace BankingLedger
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string loginId = "";
            int acctLoggedInto = 0;

            // Re-create accountList, loginId and acctLoggedInto from session variable
            AccountList accountList = Session["accountList"] as AccountList;

            if (Session["loginId"] != null)
            {
                loginId = Session["loginId"].ToString();
            }
            if (Session["acctLoggedInto"] != null)
            {
                acctLoggedInto = Convert.ToInt32(Session["acctLoggedInto"]);
            }

            // If already logged in, log them out and notify them
            if (loginId != "")
            {
                loginId = "";
                acctLoggedInto = 0;
                LabelLoggedIn.Text = "You are being logged out of the current account.<br />";
            }

            // Search for account with same credentials
            foreach (Account acct in accountList)
            {
                if (acct.LoginId == tbLoginId.Text && acct.Password == tbPassword.Text)
                {
                    loginId = acct.LoginId;
                    acctLoggedInto = acct.AccountNumber;
                    LabelLoggedIn.Text += "Welcome " + acct.FirstName + "! You are logged in.";
                    break;
                }
            }

            // Ensure user is logged in
            if (loginId == "")
            {
                LabelLoggedIn.Text += "Can not find an account that matches your information. Please try again.";
            }

            // Refresh session variables
            if (loginId == "")
            {
                Session["loginId"] = null;
                Session["acctLoggedInto"] = null;
            }
            else
            {
                Session["loginId"] = loginId.ToString();
                Session["acctLoggedInto"] = acctLoggedInto.ToString();
            }
        }
    }
}