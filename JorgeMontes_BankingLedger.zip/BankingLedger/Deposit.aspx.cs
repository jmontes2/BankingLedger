﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConsoleBankingLedger;

namespace BankingLedger
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // If not logged in, send them to the login screen
                if (Session["loginId"] == null)
                {
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

        protected void btnDeposit_Click(object sender, EventArgs e)
        {
            string loginId = "";
            int acctLoggedInto = 0;

            // Re-create accountList, transactionList, loginId and acctLoggedInto from session variable
            AccountList accountList = Session["accountList"] as AccountList;
            TransactionList transactionList = Session["transactionList"] as TransactionList;

            if (Session["loginId"] != null)
            {
                loginId = Session["loginId"].ToString();
            }

            if (Session["acctLoggedInto"] != null)
            {
                acctLoggedInto = Convert.ToInt32(Session["acctLoggedInto"]);
            }

            // Make deposit, and add it to TransactionList collection
            transactionList.AddTransaction(acctLoggedInto, DateTime.Now, TransactionType.Deposit, Convert.ToDecimal(tbDeposit.Text));

            // Update account balance
            foreach (Account acct in accountList)
            {
                if (acct.AccountNumber == acctLoggedInto)
                {
                    acct.Balance += Convert.ToDecimal(tbDeposit.Text);
                    //LabelDeposited.Text = "Balance: " + acct.Balance.ToString();    // Uncomment for testing
                    break;
                }
            }
            LabelDeposited.Text += "Amount deposit complete.";

            // Uncomment for testing
            //foreach (Transaction t in transactionList)
            //{
            //    LabelDeposited.Text += "<br />" + t.AccountNumber.ToString() + "  " +
            //            t.TransType.ToString() + "  " + t.TransactionAmount.ToString();
            //}

            // Refresh session variables
            if (loginId == "")
            {
                Session["loginId"] = null;
                Session["acctLoggedInto"] = null;
            }
            else
            {
                Session["loginId"] = loginId.ToString();
                Session["acctLoggedInto"] = acctLoggedInto.ToString();
                Session["accountList"] = accountList;
                Session["transactionList"] = transactionList;
            }
        }
    }
}