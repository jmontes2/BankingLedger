﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConsoleBankingLedger;

namespace BankingLedger
{
    public partial class BankingLedger : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["accountList"] == null)
                {
                    Account objAccount = new Account("dummy", "dummy", "dummy", "dummy");   // Unused object to set acct# to 0
                    AccountList accountList = new AccountList();                            // List of accounts
                    TransactionList transactionList = new TransactionList();                // Transaction History

                    // Create and assign session variable
                    Session["accountList"] = accountList;
                    Session["transactionList"] = transactionList;
                }
            }
        }
    }
}