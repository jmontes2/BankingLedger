﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConsoleBankingLedger;

namespace BankingLedger
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string loginId = "";
                int acctLoggedInto = 0;

                // If not logged in, send them to the login screen
                if (Session["loginId"] == null)
                {
                    Response.Redirect("~/Login.aspx");
                }
                // Re-create accountList, loginId and acctLoggedInto from session variable
                AccountList accountList = Session["accountList"] as AccountList;

                if (Session["loginId"] != null)
                {
                    loginId = Session["loginId"].ToString();
                }

                if (Session["acctLoggedInto"] != null)
                {
                    acctLoggedInto = Convert.ToInt32(Session["acctLoggedInto"]);
                }

                // Find account, and display balance
                foreach (Account acct in accountList)
                {
                    if (acct.AccountNumber == acctLoggedInto)
                    {
                        lblBalance.Text += acct.Balance.ToString();
                        break;
                    }
                }
            }
        }
    }
}