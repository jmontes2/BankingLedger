﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConsoleBankingLedger;

namespace BankingLedger
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string loginId = "";
            int acctLoggedInto = 0;

            // Re-create accountList, loginId and acctLoggedInto from session variable
            AccountList accountList = Session["accountList"] as AccountList;

            if (Session["loginId"] != null)
            {
                loginId = Session["loginId"].ToString();
            }
            if (Session["acctLoggedInto"] != null)
            {
                acctLoggedInto = Convert.ToInt32(Session["acctLoggedInto"]);
            }

            // If already logged in, log them out and notify them
            if (loginId != "")
            {
                loginId = "";
                acctLoggedInto = 0;
                lblAcctCreated.Text = "You are being logged out of the current account.<br />";
            }

            // Create account and add it to the AccountList
            Account objAccount = new Account(tbLastName.Text, tbFirstName.Text, tbLoginId.Text, tbPassword.Text);
            accountList.Add(objAccount);
            lblAcctCreated.Text += "Account created. Your account number is: " + objAccount.AccountNumber.ToString();

            // Log them into account just created
            loginId = tbLoginId.Text;
            acctLoggedInto = objAccount.AccountNumber;


            // Uncomment for testing
            //lblAcctCreated.Text += "<br />";
            //foreach (Account acct in accountList)
            //{
            //    lblAcctCreated.Text += acct.AccountNumber.ToString() + "  " +
            //            acct.Lastname + "  " + acct.Balance.ToString() + ",";
            //}

            // Refresh session variables
            if (loginId == "")
            {
                Session["loginId"] = null;
                Session["acctLoggedInto"] = null;
            }
            else
            {
                Session["loginId"] = loginId.ToString();
                Session["acctLoggedInto"] = acctLoggedInto.ToString();
                Session["accountList"] = accountList;
            }
        }
    }
}