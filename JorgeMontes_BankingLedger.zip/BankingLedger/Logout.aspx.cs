﻿// Jorge Montes (760)214-3100
// 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BankingLedger
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Clear login keys, leave lists intact
                Session.Remove("loginId");
                Session.Remove("acctLoggedInto");

                // Notify user they have been logged out
                LabelLoggedOut.Text = "You have successfully logged out.";
            }
        }
    }
}